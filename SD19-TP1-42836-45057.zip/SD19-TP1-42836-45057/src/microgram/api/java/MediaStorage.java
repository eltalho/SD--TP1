package microgram.api.java;

import microgram.api.java.Result;

public interface MediaStorage {

	Result<byte[]> download(String id);

	Result<Void> delete(String id);

	Result<String> upload(byte[] bytes);

}
